import 'dart:async';
import 'package:flutter/material.dart';

class QuestionPage extends StatefulWidget {
  const QuestionPage({super.key});

  @override
  QuestionPageState createState() => QuestionPageState();
}



class _QuestionPageState extends State<QuestionPage> {
  int _currentQuestionIndex = 0;
  int _score = 0;
  int _timeLeft = 20; // Tempo inicial para responder (em segundos)
  late Timer _timer;

  final List<Map<String, Object>> _questions = [
    {
      'questionText': 'Qual a velocidade máxima permitida em uma via urbana?',
      'answers': [
        {'text': '50 km/h', 'score': 1},
        {'text': '80 km/h', 'score': 0},
        {'text': '100 km/h', 'score': 0},
      ],
    },
    {
      'questionText': 'Qual a carta necessária para poder conduzir carro?',
      'answers': [
        {'text': 'Carta A1', 'score': 0},
        {'text': 'Carta B', 'score': 1},
        {'text': 'Carta B1', 'score': 0},
      ],
    },
    {
      'questionText': 'Qual a distância mínima de segurança entre veículos?',
      'answers': [
        {'text': '1 metro', 'score': 0},
        {'text': '2 metros', 'score': 0},
        {'text': '5 metros', 'score': 1},
      ],
    },
    {
      'questionText': 'O que é preciso fazer ao chegar a um stop?',
      'answers': [
        {'text': 'Abrandar e verificar se vem algum veiculo', 'score': 1},
        {'text': 'Parar', 'score': 0},
        {'text': 'Nada', 'score': 0},
      ],
    },
    
  ];

  void _answerQuestion(int score) {
    setState(() {
      _score += score;
      _currentQuestionIndex++;
    });
  }
  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void _startTimer() {
    const oneSec = Duration(seconds: 1);
    _timer;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Perguntas'),
      ),
      body: _currentQuestionIndex < _questions.length
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  _questions[_currentQuestionIndex]['questionText'] as String,
                  style: const TextStyle(fontSize: 24),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                ...(_questions[_currentQuestionIndex]['answers'] as List<Map<String, Object>>)
                    .map((answer) {
                  return ElevatedButton(
                    child: Text(answer['text'] as String),
                    onPressed: () => _answerQuestion(answer['score'] as int),
                  );
                })
              ],
            )
          : Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Completas-te o jogo!',
                    style: TextStyle(fontSize: 24),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Pontuação: $_score',
                    style: const TextStyle(fontSize: 24),
                  ),
                  ElevatedButton(
                    child: const Text('Reiniciar Quiz'),
                    onPressed: () {
                      setState(() {
                        _currentQuestionIndex = 0;
                        _score = 0;
                      });
                    },
                  ),
                ],
              ),
            ),
    );
  }
}

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}