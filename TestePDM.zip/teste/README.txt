Este projeto tem como objetivo, criar uma jogo para android com perguntas de código de estrada.
O utilizador tem de se resgistar pela primeira vez para poder usufruir do jogo. Foi usado Firebase para armazenar os dados do utilizador para
proximas utilizações. o projeto tem 4 paginas, home_page, login_page, question_page e register_page.

Este jogo tem como objetivo também incentivar os utilizadores a estudarem o código mais vezes de forma a evitar desastres,
mas também incentivar os novos programadores a experimentarem novas linguas de programação como o flutter.